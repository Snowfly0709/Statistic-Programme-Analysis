/*
 * Tai-e: A Static Analysis Framework for Java
 *
 * Copyright (C) 2022 Tian Tan <tiantan@nju.edu.cn>
 * Copyright (C) 2022 Yue Li <yueli@nju.edu.cn>
 *
 * This file is part of Tai-e.
 *
 * Tai-e is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation, either version 3
 * of the License, or (at your option) any later version.
 *
 * Tai-e is distributed in the hope that it will be useful,but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General
 * Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with Tai-e. If not, see <https://www.gnu.org/licenses/>.
 */

package pascal.taie.analysis.dataflow.analysis;

import pascal.taie.analysis.MethodAnalysis;
import pascal.taie.analysis.dataflow.analysis.constprop.CPFact;
import pascal.taie.analysis.dataflow.analysis.constprop.ConstantPropagation;
import pascal.taie.analysis.dataflow.analysis.constprop.Value;
import pascal.taie.analysis.dataflow.fact.DataflowResult;
import pascal.taie.analysis.dataflow.fact.SetFact;
import pascal.taie.analysis.graph.cfg.CFG;
import pascal.taie.analysis.graph.cfg.CFGBuilder;
import pascal.taie.analysis.graph.cfg.Edge;
import pascal.taie.config.AnalysisConfig;
import pascal.taie.ir.IR;
import pascal.taie.ir.exp.*;
import pascal.taie.ir.stmt.AssignStmt;
import pascal.taie.ir.stmt.If;
import pascal.taie.ir.stmt.Stmt;
import pascal.taie.ir.stmt.SwitchStmt;

import java.util.*;

public class DeadCodeDetection extends MethodAnalysis {

    public static final String ID = "deadcode";

    public DeadCodeDetection(AnalysisConfig config) {
        super(config);
    }

    @Override
    public Set<Stmt> analyze(IR ir) {
        // obtain CFG
        CFG<Stmt> cfg = ir.getResult(CFGBuilder.ID);
        // obtain result of constant propagation
        DataflowResult<Stmt, CPFact> constants =
                ir.getResult(ConstantPropagation.ID);
        // obtain result of live variable analysis
        DataflowResult<Stmt, SetFact<Var>> liveVars =
                ir.getResult(LiveVariableAnalysis.ID);
        // keep statements (dead code) sorted in the resulting set
        Set<Stmt> deadCode = new TreeSet<>(Comparator.comparing(Stmt::getIndex));
        // TODO - finish me

        ArrayList<Stmt> stmts = new ArrayList<>();
        Set<Stmt> hasReach = new HashSet<>();
        Set<Stmt> canReach = new HashSet<>();
        stmts.add(cfg.getEntry());
        canReach.add(cfg.getEntry());
        canReach.add(cfg.getExit());
        // iterate over all statements in the CFG
        while (!stmts.isEmpty()) {
            Stmt stmt = stmts.remove(0);
            // add current statement to hasReach
            hasReach.add(stmt);
            // if the statement is an assignment
            if(stmt instanceof AssignStmt assignStmt){
                SetFact<Var> live = liveVars.getResult(assignStmt);
                LValue def = (assignStmt).getLValue();
                RValue use = (assignStmt).getRValue();
                boolean isDead = false;
                if(def instanceof Var){
                    if(!live.contains((Var)def) && hasNoSideEffect(use)){
                        isDead = true;
                    }
                }
                if(!isDead){
                    canReach.add(assignStmt);
                }
                for(Stmt succ : cfg.getSuccsOf(stmt)){
                    if(!hasReach.contains(succ)){
                        stmts.add(succ);
                    }
                }
            }
            // if the statement is an if statement
            else if(stmt instanceof If){
                CPFact fact = constants.getResult(stmt);
                ConditionExp conditionExp = ((If) stmt).getCondition();
                ConditionExp.Op op = conditionExp.getOperator();
                Value value = ConstantPropagation.evaluate(conditionExp, fact);
                canReach.add(stmt);
                if(value.isConstant()){
                    if(value.getConstant()==1){
                        for(Edge<Stmt> edge : cfg.getOutEdgesOf(stmt)){
                            if(edge.getKind()==Edge.Kind.IF_TRUE){
                                if(!hasReach.contains(edge.getTarget())){
                                    stmts.add(edge.getTarget());
                                }
                            }
                        }
                    }
                    else{
                        for(Edge<Stmt> edge : cfg.getOutEdgesOf(stmt)){
                            if(edge.getKind()==Edge.Kind.IF_FALSE){
                                if(!hasReach.contains(edge.getTarget())){
                                    stmts.add(edge.getTarget());
                                }
                            }
                        }
                    }
                }
                else{
                    for(Stmt succ : cfg.getSuccsOf(stmt)){
                        if(!hasReach.contains(succ)){
                            stmts.add(succ);
                        }
                    }
                }
            }
            // if the statement is a switch statement
            else if(stmt instanceof SwitchStmt) {
                CPFact fact = constants.getResult(stmt);
                Var var = ((SwitchStmt) stmt).getVar();
                canReach.add(stmt);
                if(fact.get(var).isConstant()){
                    int value = fact.get(var).getConstant();
                    boolean findCase = false;
                    for(Edge<Stmt> edge : cfg.getOutEdgesOf(stmt)){
                        if(edge.getKind()==Edge.Kind.SWITCH_CASE){
                            if(edge.getCaseValue()==value){
                                if(!hasReach.contains(edge.getTarget())){
                                    stmts.add(edge.getTarget());
                                    findCase = true;
                                }
                            }
                        }
                    }
                    if(!findCase){
                        for(Edge<Stmt> edge : cfg.getOutEdgesOf(stmt)){
                            if(edge.getKind()==Edge.Kind.SWITCH_DEFAULT){
                                if(!hasReach.contains(edge.getTarget())){
                                    stmts.add(edge.getTarget());
                                }
                            }
                        }
                    }
                }
                else{
                    for(Stmt succ : cfg.getSuccsOf(stmt)){
                        if(!hasReach.contains(succ)){
                            stmts.add(succ);
                        }
                    }
                }
            }
            // other statements
            else{
                canReach.add(stmt);
                for(Stmt succ : cfg.getSuccsOf(stmt)){
                    if(!hasReach.contains(succ)){
                        stmts.add(succ);
                    }
                }
            }
        }
        for(Stmt stmt : ir.getStmts()){
            if(!canReach.contains(stmt)){
                deadCode.add(stmt);
            }
        }
        // Your task is to recognize dead code in ir and add it to deadCode
        return deadCode;
    }

    /**
     * @return true if given RValue has no side effect, otherwise false.
     */
    private static boolean hasNoSideEffect(RValue rvalue) {
        // new expression modifies the heap
        if (rvalue instanceof NewExp ||
                // cast may trigger ClassCastException
                rvalue instanceof CastExp ||
                // static field access may trigger class initialization
                // instance field access may trigger NPE
                rvalue instanceof FieldAccess ||
                // array access may trigger NPE
                rvalue instanceof ArrayAccess) {
            return false;
        }
        if (rvalue instanceof ArithmeticExp) {
            ArithmeticExp.Op op = ((ArithmeticExp) rvalue).getOperator();
            // may trigger DivideByZeroException
            return op != ArithmeticExp.Op.DIV && op != ArithmeticExp.Op.REM;
        }
        return true;
    }
}
